import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "@/contexts/ThemeContext";
import { SimulationProvider } from "@/contexts/SimulationContext";
import Home from "@/pages/Home";
import DigitalTwin from "@/pages/DigitalTwin";
import LegacyDigitalTwin from "@/pages/LegacyDigitalTwin";
import GuestSurvey from "@/pages/GuestSurvey";
import Analytics from "@/pages/Analytics";
import Energy from "@/pages/Energy";
import Guests from "@/pages/Guests";
import Settings from "@/pages/Settings";
import Sustainability from "@/pages/Sustainability";
import NotFound from "@/pages/not-found";
import Layout from "@/components/Layout";

function Router() {
  return (
    <Switch>
      {/* Main Dashboard */}
      <Route path="/">
        {() => (
          <Layout>
            <Home />
          </Layout>
        )}
      </Route>
      
      {/* Digital Twin 3D View */}
      <Route path="/digital-twin">
        {() => (
          <Layout>
            <DigitalTwin />
          </Layout>
        )}
      </Route>

      {/* Legacy Digital Twin 3D View */}
      <Route path="/legacy-digital-twin">
        {() => (
          <Layout>
            <LegacyDigitalTwin />
          </Layout>
        )}
      </Route>

      {/* Guest Survey Page (No Layout for immersion) */}
      <Route path="/guest-survey">
        {() => (
          <GuestSurvey />
        )}
      </Route>

      {/* Analytics Page */}
      <Route path="/analytics">
        {() => (
          <Layout>
            <Analytics />
          </Layout>
        )}
      </Route>

      {/* Energy Management Page */}
      <Route path="/energy">
        {() => (
          <Layout>
            <Energy />
          </Layout>
        )}
      </Route>

      {/* Guest Preferences Page */}
      <Route path="/guests">
        {() => (
          <Layout>
            <Guests />
          </Layout>
        )}
      </Route>

      {/* Settings Page */}
      <Route path="/settings">
        {() => (
          <Layout>
            <Settings />
          </Layout>
        )}
      </Route>

      {/* Sustainability Page */}
      <Route path="/sustainability">
        {() => (
          <Layout>
            <Sustainability />
          </Layout>
        )}
      </Route>

      {/* Fallback 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="dark">
        <SimulationProvider>
          <Router />
          <Toaster />
        </SimulationProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
