import { useSimulation } from "@/contexts/SimulationContext";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Activity, ArrowLeft, Cpu, Thermometer, Smile } from "lucide-react";

export default function SmartTracePanel() {
  const { aiLogs } = useSimulation();
  
  // Get the latest decision
  const latestDecision = aiLogs.length > 0 ? aiLogs[0] : null;

  return (
    <Card className="bg-slate-950 border-slate-800 h-full flex flex-col overflow-hidden relative">
      {/* Header */}
      <div className="absolute top-3 right-3 z-10 flex items-center gap-2">
        <div className="animate-pulse w-2 h-2 rounded-full bg-blue-500"></div>
        <span className="text-xs text-blue-400 font-mono">LIVE TRACE</span>
      </div>

      <div className="flex-1 flex items-center justify-center p-4 relative">
        {/* Background Grid Effect */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b_1px,transparent_1px),linear-gradient(to_bottom,#1e293b_1px,transparent_1px)] bg-[size:20px_20px] opacity-20"></div>

        {latestDecision ? (
          <div className="w-full max-w-3xl grid grid-cols-4 gap-4 relative z-10">
            
            {/* STEP 1: SENSOR READING */}
            <div className="flex flex-col items-center text-center space-y-3 group">
              <div className="w-12 h-12 rounded-full bg-slate-900 border-2 border-yellow-500/50 flex items-center justify-center shadow-[0_0_15px_rgba(234,179,8,0.2)] group-hover:scale-110 transition-transform duration-500">
                <Thermometer className="w-6 h-6 text-yellow-500" />
              </div>
              <div className="space-y-1">
                <div className="text-xs text-yellow-500 font-bold tracking-wider">القراءة (Sensor)</div>
                <div className="text-xs text-slate-300 bg-slate-900/80 px-2 py-1 rounded border border-slate-800">
                  {latestDecision.event.includes('حرارة') ? 'تغير حراري' : 'إشغال/حركة'}
                </div>
              </div>
            </div>

            {/* ARROW 1 */}
            <div className="flex items-center justify-center">
              <ArrowLeft className="w-6 h-6 text-slate-700 animate-pulse" />
            </div>

            {/* STEP 2: EVENT DETECTION */}
            <div className="flex flex-col items-center text-center space-y-3 group">
              <div className="w-12 h-12 rounded-full bg-slate-900 border-2 border-red-500/50 flex items-center justify-center shadow-[0_0_15px_rgba(239,68,68,0.2)] group-hover:scale-110 transition-transform duration-500 delay-100">
                <Activity className="w-6 h-6 text-red-500" />
              </div>
              <div className="space-y-1">
                <div className="text-xs text-red-500 font-bold tracking-wider">الحدث (Event)</div>
                <div className="text-xs text-slate-300 bg-slate-900/80 px-2 py-1 rounded border border-slate-800 max-w-[120px] truncate" title={latestDecision.event}>
                  {latestDecision.event}
                </div>
              </div>
            </div>

            {/* ARROW 2 */}
            <div className="flex items-center justify-center">
              <ArrowLeft className="w-6 h-6 text-slate-700 animate-pulse delay-75" />
            </div>

            {/* STEP 3: AI LOGIC */}
            <div className="flex flex-col items-center text-center space-y-3 group">
              <div className="w-12 h-12 rounded-full bg-slate-900 border-2 border-blue-500/50 flex items-center justify-center shadow-[0_0_15px_rgba(59,130,246,0.2)] group-hover:scale-110 transition-transform duration-500 delay-200">
                <Cpu className="w-6 h-6 text-blue-500 animate-spin-slow" />
              </div>
              <div className="space-y-1">
                <div className="text-xs text-blue-500 font-bold tracking-wider">القرار (AI Action)</div>
                <div className="text-xs text-slate-300 bg-slate-900/80 px-2 py-1 rounded border border-slate-800 max-w-[120px] truncate" title={latestDecision.action}>
                  {latestDecision.action}
                </div>
              </div>
            </div>

            {/* ARROW 3 */}
            <div className="flex items-center justify-center">
              <ArrowLeft className="w-6 h-6 text-slate-700 animate-pulse delay-150" />
            </div>

            {/* STEP 4: OUTCOME */}
            <div className="flex flex-col items-center text-center space-y-3 group">
              <div className="w-12 h-12 rounded-full bg-slate-900 border-2 border-green-500/50 flex items-center justify-center shadow-[0_0_15px_rgba(34,197,94,0.2)] group-hover:scale-110 transition-transform duration-500 delay-300">
                <Smile className="w-6 h-6 text-green-500" />
              </div>
              <div className="space-y-1">
                <div className="text-xs text-green-500 font-bold tracking-wider">النتيجة (Outcome)</div>
                <div className="text-xs text-slate-300 bg-slate-900/80 px-2 py-1 rounded border border-slate-800 max-w-[120px] truncate" title={latestDecision.outcome}>
                  {latestDecision.outcome}
                </div>
              </div>
            </div>

          </div>
        ) : (
          <div className="text-slate-500 text-sm animate-pulse">
            النظام في حالة مراقبة... بانتظار أحداث جديدة
          </div>
        )}
      </div>
      
      {/* Footer Info */}
      {latestDecision && (
        <div className="bg-slate-900/50 p-2 border-t border-slate-800 flex justify-between items-center text-[10px] text-slate-400 px-4">
          <span className="font-mono">غرفة {latestDecision.roomId || 'عام'} • تدخل ذكي نشط</span>
          <span className="font-mono">{latestDecision.timestamp}</span>
        </div>
      )}
    </Card>
  );
}
