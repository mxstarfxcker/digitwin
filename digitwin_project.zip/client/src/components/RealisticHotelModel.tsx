import React, { useRef, useState, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Text, Environment, ContactShadows, Stars, Sky } from '@react-three/drei';
import * as THREE from 'three';

// Types for props
interface RoomData {
  id: string;
  status: 'occupied' | 'vacant' | 'cleaning' | 'maintenance' | 'isolated';
  temperature?: number;
  humidity?: number;
  power?: number;
}

interface RealisticHotelModelProps {
  rooms: RoomData[];
  onRoomClick: (roomId: string) => void;
  isEmergency: boolean;
  isolatedFloors: number[];
}

// Helper to get color based on status and floor
const getRoomColor = (status: string, isControlGroup: boolean, isEmergency: boolean, isIsolated: boolean) => {
  if (isEmergency) return '#ff0000'; // Red flashing for emergency
  if (isIsolated) return '#1a1a1a'; // Dark for isolated
  
  if (isControlGroup) {
    return '#ffcc80'; // Warm static light for control group (Floor 1)
  }

  switch (status) {
    case 'occupied': return '#ef4444'; // Red
    case 'vacant': return '#22c55e'; // Green
    case 'cleaning': return '#eab308'; // Yellow
    case 'maintenance': return '#f97316'; // Orange
    default: return '#22c55e'; // Default green
  }
};

const Room = ({ 
  position, 
  roomId, 
  status, 
  isControlGroup, 
  onClick, 
  isEmergency,
  isIsolated
}: { 
  position: [number, number, number], 
  roomId: string, 
  status: string, 
  isControlGroup: boolean, 
  onClick: (id: string) => void,
  isEmergency: boolean,
  isIsolated: boolean
}) => {
  const [hovered, setHovered] = useState(false);
  const mesh = useRef<THREE.Mesh>(null);
  const doorRef = useRef<THREE.Group>(null);
  
  // Emergency flashing effect
  useFrame((state) => {
    if (isEmergency && mesh.current) {
      const t = state.clock.getElapsedTime();
      const intensity = (Math.sin(t * 10) + 1) / 2; // Fast flash
      (mesh.current.material as THREE.MeshStandardMaterial).emissiveIntensity = 0.5 + intensity;
    } else if (mesh.current) {
      (mesh.current.material as THREE.MeshStandardMaterial).emissiveIntensity = isControlGroup ? 0.8 : 0.5;
    }

    // Door Animation
    if (doorRef.current) {
      const targetRotation = status === 'occupied' ? Math.PI / 3 : 0; // Open 60 deg if occupied
      doorRef.current.rotation.y = THREE.MathUtils.lerp(doorRef.current.rotation.y, targetRotation, 0.1);
    }
  });

  const color = getRoomColor(status, isControlGroup, isEmergency, isIsolated);
  const isOccupied = status === 'occupied';

  return (
    <group position={position}>
      {/* Room Box (Walls) */}
      <mesh position={[0, 0, -0.5]}>
        <boxGeometry args={[1.8, 1.2, 1.5]} />
        <meshStandardMaterial color="#1e293b" side={THREE.BackSide} />
      </mesh>

      {/* Interior Furniture (Visible through glass) */}
      <group position={[0, -0.4, -0.5]}>
        {/* Bed */}
        <mesh position={[-0.5, 0, -0.2]}>
          <boxGeometry args={[0.6, 0.2, 0.8]} />
          <meshStandardMaterial color={isOccupied ? "#3b82f6" : "#475569"} />
        </mesh>
        {/* Pillow */}
        <mesh position={[-0.5, 0.15, -0.5]}>
          <boxGeometry args={[0.4, 0.1, 0.2]} />
          <meshStandardMaterial color="#e2e8f0" />
        </mesh>
        {/* Table */}
        <mesh position={[0.6, 0, 0]}>
          <boxGeometry args={[0.4, 0.3, 0.4]} />
          <meshStandardMaterial color="#78350f" />
        </mesh>
        {/* Lamp */}
        <mesh position={[0.6, 0.2, 0]}>
          <cylinderGeometry args={[0.05, 0.08, 0.15]} />
          <meshStandardMaterial color="#fbbf24" emissive="#fbbf24" emissiveIntensity={isOccupied ? 1 : 0} />
        </mesh>
      </group>

      {/* Door Group (Animated) */}
      <group ref={doorRef} position={[0.8, -0.1, 0.1]}> 
        {/* Pivot point is at the hinge */}
        <mesh position={[-0.2, 0, 0]}> {/* Offset geometry so it rotates around hinge */}
          <boxGeometry args={[0.4, 0.8, 0.05]} />
          <meshStandardMaterial color="#475569" />
        </mesh>
        {/* Door Handle */}
        <mesh position={[-0.35, 0, 0.04]}>
          <sphereGeometry args={[0.03]} />
          <meshStandardMaterial color="#fbbf24" metalness={1} roughness={0.2} />
        </mesh>
      </group>

      {/* Room Glass Window (Front) */}
      <mesh 
        ref={mesh}
        onClick={(e) => { e.stopPropagation(); onClick(roomId); }}
        onPointerOver={() => setHovered(true)}
        onPointerOut={() => setHovered(false)}
        position={[0, 0, 0.1]} // Slightly in front
      >
        <boxGeometry args={[1.8, 1.2, 0.05]} />
        <meshStandardMaterial 
          color={color}
          transparent
          opacity={0.3} // More transparent to see inside
          metalness={0.9}
          roughness={0.1}
          emissive={color}
          emissiveIntensity={0.2}
        />
      </mesh>

      {/* Room Frame/Balcony */}
      <mesh position={[0, -0.7, 0.2]}>
        <boxGeometry args={[2, 0.1, 0.5]} />
        <meshStandardMaterial color="#333" roughness={0.8} />
      </mesh>
      
      {/* Room Number */}
      <Text
        position={[0, 0.4, 0.2]}
        fontSize={0.3}
        color="white"
        anchorX="center"
        anchorY="middle"
        visible={hovered}
        renderOrder={1}
      >
        {roomId}
      </Text>
    </group>
  );
};

const Floor = ({ 
  level, 
  rooms, 
  onRoomClick, 
  isEmergency, 
  isIsolated 
}: { 
  level: number, 
  rooms: RoomData[], 
  onRoomClick: (id: string) => void,
  isEmergency: boolean,
  isIsolated: boolean
}) => {
  const isControlGroup = level === 1;
  const yPos = (level - 1) * 2 + 1; // Calculate height based on level

  return (
    <group position={[0, yPos, 0]}>
      {/* Floor Slab */}
      <mesh position={[0, -0.8, 0]}>
        <boxGeometry args={[14, 0.2, 4]} />
        <meshStandardMaterial color="#1f2937" roughness={0.5} metalness={0.5} />
      </mesh>

      {/* Rooms */}
      {rooms.map((room, index) => {
        // Arrange rooms in a row
        const xPos = (index - 2.5) * 2.2; 
        return (
          <Room
            key={room.id}
            position={[xPos, 0, 1.5]}
            roomId={room.id}
            status={room.status}
            isControlGroup={isControlGroup}
            onClick={onRoomClick}
            isEmergency={isEmergency}
            isIsolated={isIsolated}
          />
        );
      })}
      
      {/* Floor Label */}
      <Text
        position={[-8, 0, 0]}
        rotation={[0, Math.PI / 2, 0]}
        fontSize={0.8}
        color={isControlGroup ? "#ffcc80" : "white"}
      >
        {isControlGroup ? `Floor ${level} (Control)` : `Floor ${level}`}
      </Text>
    </group>
  );
};

const Building = ({ rooms, onRoomClick, isEmergency, isolatedFloors }: RealisticHotelModelProps) => {
  // Group rooms by floor
  const floors = useMemo(() => {
    const grouped: { [key: number]: RoomData[] } = {};
    for (let i = 1; i <= 5; i++) grouped[i] = [];
    
    rooms.forEach(room => {
      const floorNum = parseInt(room.id.toString().charAt(0));
      if (grouped[floorNum]) {
        grouped[floorNum].push(room);
      }
    });
    return grouped;
  }, [rooms]);

  return (
    <group>
      {/* Main Structure Pillars */}
      <mesh position={[-7, 5, 0]}>
        <boxGeometry args={[0.5, 12, 4]} />
        <meshStandardMaterial color="#111827" roughness={0.9} />
      </mesh>
      <mesh position={[7, 5, 0]}>
        <boxGeometry args={[0.5, 12, 4]} />
        <meshStandardMaterial color="#111827" roughness={0.9} />
      </mesh>
      
      {/* Back Wall */}
      <mesh position={[0, 5, -1.8]}>
        <boxGeometry args={[14, 12, 0.2]} />
        <meshStandardMaterial color="#374151" />
      </mesh>

      {/* Floors */}
      {[1, 2, 3, 4, 5].map(level => (
        <Floor
          key={level}
          level={level}
          rooms={floors[level] || []}
          onRoomClick={onRoomClick}
          isEmergency={isEmergency}
          isIsolated={isolatedFloors.includes(level)}
        />
      ))}

      {/* Roof */}
      <mesh position={[0, 11, 0]}>
        <boxGeometry args={[15, 0.5, 5]} />
        <meshStandardMaterial color="#111827" />
      </mesh>
      
      {/* Entrance / Ground Floor */}
      <group position={[0, -1, 2]}>
        <mesh position={[0, 0, 0]}>
          <boxGeometry args={[6, 0.1, 4]} />
          <meshStandardMaterial color="#4b5563" />
        </mesh>
        <Text position={[0, 0.5, 2]} fontSize={0.5} color="#fbbf24">
          HOTEL ENTRANCE
        </Text>
      </group>
    </group>
  );
};

export default function RealisticHotelModel(props: RealisticHotelModelProps) {
  return (
    <div className="w-full h-full bg-slate-900 overflow-hidden relative shadow-2xl">
      {/* Instructions are now in the parent component */}
      
      <Canvas camera={{ position: [15, 10, 20], fov: 45 }}>
        <color attach="background" args={['#0f172a']} />
        
        {/* Lighting */}
        <ambientLight intensity={0.5} />
        <pointLight position={[10, 10, 10]} intensity={1} />
        <spotLight position={[-10, 20, 10]} angle={0.3} penumbra={1} intensity={2} castShadow />
        
        {/* Environment */}
        <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={1} />
        <Sky sunPosition={[100, 20, 100]} turbidity={0.1} rayleigh={0.5} />
        <Environment preset="city" />

        {/* The Hotel */}
        <Building {...props} />

        {/* Ground */}
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -2, 0]} receiveShadow>
          <planeGeometry args={[100, 100]} />
          <meshStandardMaterial color="#020617" roughness={0.8} metalness={0.2} />
        </mesh>
        
        <ContactShadows resolution={1024} scale={50} blur={2} opacity={0.5} far={10} color="#000000" />
        
        <OrbitControls 
          enablePan={true} 
          enableZoom={true} 
          enableRotate={true}
          minPolarAngle={0}
          maxPolarAngle={Math.PI / 2 - 0.1} // Prevent going below ground
        />
      </Canvas>
    </div>
  );
}
