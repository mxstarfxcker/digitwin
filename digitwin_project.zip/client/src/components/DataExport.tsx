import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { FileSpreadsheet, Loader2 } from "lucide-react";
import { useSimulation } from "@/contexts/SimulationContext";
import { useToast } from "@/hooks/use-toast";
import * as XLSX from 'xlsx';

export default function DataExport() {
  const [isExporting, setIsExporting] = useState(false);
  const { energyData, aiLogs, rooms } = useSimulation();
  const { toast } = useToast();

  const handleExport = () => {
    setIsExporting(true);
    toast({ title: "جاري تصدير البيانات...", description: "يتم الآن تجهيز ملف Excel" });

    try {
      // Create a new workbook
      const wb = XLSX.utils.book_new();

      // 1. Energy Data Sheet
      const energyWS = XLSX.utils.json_to_sheet(energyData);
      XLSX.utils.book_append_sheet(wb, energyWS, "Energy Data");

      // 2. AI Logs Sheet (Enhanced)
      const enhancedAiLogs = aiLogs.map(log => ({
        'المعرف': log.id,
        'الوقت': log.timestamp,
        'رقم الغرفة': log.roomId || 'N/A',
        'الحدث': log.event,
        'الإجراء المتخذ': log.action,
        'النتيجة': log.outcome,
        'التفاصيل والمصدر': log.details || 'N/A'
      }));
      const aiWS = XLSX.utils.json_to_sheet(enhancedAiLogs);
      XLSX.utils.book_append_sheet(wb, aiWS, "AI Decisions");

      // 3. Room Status Sheet (Enhanced)
      const roomData = Object.values(rooms).map(r => {
        // Calculate savings for this room (simulated)
        const baselineConsumption = r.status === 'occupied' ? 10 : 5;
        const actualConsumption = r.floor === 1 ? baselineConsumption : (r.status === 'occupied' ? 7 : 1);
        const savingsKw = baselineConsumption - actualConsumption;
        const savingsUSD = savingsKw * 0.12;

        return {
          'رقم الغرفة': r.id,
          'الطابق': r.floor,
          'الحالة': r.status === 'occupied' ? 'مشغولة' : (r.status === 'cleaning' ? 'تنظيف' : 'فارغة'),
          'نوع النزيل': r.guestType ? r.guestType.split('(')[0] : 'لا يوجد',
          'درجة الحرارة الحالية': r.temperature,
          'مستوى الإضاءة': r.light_level,
          'التجهيزات الذكية': r.amenities ? r.amenities.join(', ') : 'لا يوجد',
          'الاستهلاك المقدر (kW)': actualConsumption,
          'الاستهلاك التقليدي (kW)': baselineConsumption,
          'التوفير (kW)': savingsKw,
          'التوفير المادي ($)': savingsUSD.toFixed(2)
        };
      });
      const roomWS = XLSX.utils.json_to_sheet(roomData);
      XLSX.utils.book_append_sheet(wb, roomWS, "Room Status");

      // Write file
      XLSX.writeFile(wb, `Digital_Twin_Data_${Date.now()}.xlsx`);

      toast({ title: "تم التصدير بنجاح", description: "تم تحميل ملف Excel يحتوي على كافة البيانات" });
    } catch (error) {
      console.error("Excel Export failed:", error);
      toast({ variant: "destructive", title: "فشل التصدير", description: "حدث خطأ أثناء إنشاء ملف Excel" });
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <Button 
      onClick={handleExport} 
      disabled={isExporting}
      variant="outline"
      className="bg-slate-900 border-slate-700 hover:bg-slate-800 text-green-400 hover:text-green-300"
    >
      {isExporting ? (
        <>
          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          جاري التصدير...
        </>
      ) : (
        <>
          <FileSpreadsheet className="mr-2 h-4 w-4" />
          تصدير بيانات خام (Excel)
        </>
      )}
    </Button>
  );
}
