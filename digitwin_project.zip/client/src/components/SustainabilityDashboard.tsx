import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { Activity, DollarSign, Leaf, Zap } from 'lucide-react';

interface KPICardProps {
  title: string;
  value: string;
  icon: React.ReactNode;
  trend: string;
  color: string;
}

const KPICard: React.FC<KPICardProps> = ({ title, value, icon, trend, color }) => (
  <div style={{ background: 'white', padding: '20px', borderRadius: '15px', boxShadow: '0 4px 6px rgba(0,0,0,0.05)', display: 'flex', flexDirection: 'column', gap: '10px' }}>
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
      <span style={{ color: '#64748b', fontSize: '0.9rem' }}>{title}</span>
      <div style={{ padding: '8px', borderRadius: '8px', background: color }}>{icon}</div>
    </div>
    <div style={{ fontSize: '1.8rem', fontWeight: 'bold', color: '#1e293b' }}>{value}</div>
    <div style={{ fontSize: '0.85rem', color: '#10b981', background: '#ecfdf5', width: 'fit-content', padding: '2px 8px', borderRadius: '12px' }}>
      {trend}
    </div>
  </div>
);

interface SustainabilityDashboardProps {
  onClose: () => void;
}

const SustainabilityDashboard: React.FC<SustainabilityDashboardProps> = ({ onClose }) => {
  // --- 1. البيانات المحسوبة (من تقرير الجدوى السابق) ---
  const monthlyData = [
    { name: 'يناير', تقليدي: 15400, ذكي: 11274 },
    { name: 'فبراير', تقليدي: 14800, ذكي: 10650 },
    { name: 'مارس', تقليدي: 16200, ذكي: 11900 },
    { name: 'أبريل', تقليدي: 18500, ذكي: 13200 }, // بداية الحر
    { name: 'مايو', تقليدي: 22000, ذكي: 15800 },
    { name: 'يونيو', تقليدي: 25000, ذكي: 17500 }, // ذروة الصيف
  ];

  const investmentData = [
    { month: 'Start', تكلفة_الاستثمار: 46330, العائد_التراكمي: 0 },
    { month: '3 أشهر', تكلفة_الاستثمار: 46330, العائد_التراكمي: 12378 },
    { month: '6 أشهر', تكلفة_الاستثمار: 46330, العائد_التراكمي: 24756 },
    { month: '9 أشهر', تكلفة_الاستثمار: 46330, العائد_التراكمي: 37134 },
    { month: '12 شهر', تكلفة_الاستثمار: 46330, العائد_التراكمي: 49509 }, // نقطة التعادل والربح
    { month: '15 شهر', تكلفة_الاستثمار: 46330, العائد_التراكمي: 61886 },
  ];

  return (
    <div style={{
      position: 'absolute',
      top: '5%',
      left: '5%',
      width: '90%',
      height: '90%',
      backgroundColor: 'rgba(255, 255, 255, 0.95)',
      backdropFilter: 'blur(10px)',
      borderRadius: '20px',
      boxShadow: '0 20px 50px rgba(0,0,0,0.2)',
      padding: '30px',
      overflowY: 'auto',
      zIndex: 1000,
      fontFamily: 'Tahoma, sans-serif',
      direction: 'rtl'
    }}>
      
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '30px' }}>
        <div>
          <h1 style={{ margin: 0, color: '#1e293b', fontSize: '2rem' }}>تقرير الاستدامة والجدوى الاقتصادية</h1>
          <p style={{ margin: '5px 0 0', color: '#64748b' }}>تحليل العائد على الاستثمار (ROI) لمشروع التوأم الرقمي</p>
        </div>
        <button 
          onClick={onClose}
          style={{ padding: '10px 20px', background: '#ef4444', color: 'white', border: 'none', borderRadius: '8px', cursor: 'pointer', fontWeight: 'bold' }}
        >
          إغلاق التقرير X
        </button>
      </div>

      {/* KPI Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '20px', marginBottom: '40px' }}>
        <KPICard 
          title="التوفير السنوي المتوقع" 
          value="49,509 ر.ق" 
          icon={<DollarSign color="#16a34a" size={24} />} 
          trend="+30% توفير"
          color="#dcfce7"
        />
        <KPICard 
          title="استرداد رأس المال" 
          value="11 شهر" 
          icon={<Activity color="#2563eb" size={24} />} 
          trend="سريع جداً"
          color="#dbeafe"
        />
        <KPICard 
          title="تخفيض استهلاك الطاقة" 
          value="34,000 kW" 
          icon={<Zap color="#d97706" size={24} />} 
          trend="سنوياً"
          color="#fef3c7"
        />
        <KPICard 
          title="خفض انبعاثات الكربون" 
          value="14.5 طن" 
          icon={<Leaf color="#059669" size={24} />} 
          trend="CO2e"
          color="#d1fae5"
        />
      </div>

      {/* Charts Section */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '30px' }}>
        
        {/* Chart 1: Monthly Cost Comparison */}
        <div style={{ background: 'white', padding: '20px', borderRadius: '15px', boxShadow: '0 4px 6px rgba(0,0,0,0.05)', height: '400px' }}>
          <h3 style={{ borderBottom: '1px solid #eee', paddingBottom: '10px', marginBottom: '20px', color: '#334155' }}>مقارنة تكلفة الطاقة (شهرياً)</h3>
          <ResponsiveContainer width="100%" height="85%">
            <BarChart data={monthlyData}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip 
                contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                cursor={{ fill: '#f1f5f9' }}
              />
              <Legend />
              <Bar dataKey="تقليدي" fill="#94a3b8" radius={[4, 4, 0, 0]} name="نظام تقليدي" />
              <Bar dataKey="ذكي" fill="#3b82f6" radius={[4, 4, 0, 0]} name="نظام التوأم الرقمي" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Chart 2: ROI Break-even Point */}
        <div style={{ background: 'white', padding: '20px', borderRadius: '15px', boxShadow: '0 4px 6px rgba(0,0,0,0.05)', height: '400px' }}>
          <h3 style={{ borderBottom: '1px solid #eee', paddingBottom: '10px', marginBottom: '20px', color: '#334155' }}>تحليل نقطة التعادل (Break-even Analysis)</h3>
          <ResponsiveContainer width="100%" height="85%">
            <AreaChart data={investmentData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip contentStyle={{ borderRadius: '8px' }} />
              <Legend />
              <Area type="monotone" dataKey="تكلفة_الاستثمار" stackId="1" stroke="#ef4444" fill="transparent" strokeWidth={2} name="تكلفة المشروع (ثابتة)" />
              <Area type="monotone" dataKey="العائد_التراكمي" stackId="2" stroke="#10b981" fill="#d1fae5" strokeWidth={3} name="التوفير التراكمي" />
            </AreaChart>
          </ResponsiveContainer>
          <p style={{ textAlign: 'center', fontSize: '0.8rem', color: '#64748b', marginTop: '-10px' }}>
            * يتقاطع المنحنى الأخضر مع الخط الأحمر عند الشهر 11 (نقطة استرداد الأموال)
          </p>
        </div>

      </div>
    </div>
  );
};

export default SustainabilityDashboard;
