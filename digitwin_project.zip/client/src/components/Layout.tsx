import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  LayoutDashboard, 
  Box, 
  BarChart3, 
  Settings, 
  Menu,
  Zap,
  Users,
  Sun,
  Moon,
  Leaf
} from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useTheme } from "@/contexts/ThemeContext";
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from "@/components/ui/sheet";
import { VisuallyHidden } from "@radix-ui/react-visually-hidden";

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const [location] = useLocation();
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const { theme, setTheme } = useTheme();

  const navigation = [
    { name: "لوحة القيادة", href: "/", icon: LayoutDashboard },
    { name: "التوأم الرقمي", href: "/digital-twin", icon: Box },
    { name: "تحليلات الذكاء الاصطناعي", href: "/analytics", icon: BarChart3 },
    { name: "إدارة الطاقة", href: "/energy", icon: Zap },
    { name: "الاستدامة والجدوى", href: "/sustainability", icon: Leaf },
    { name: "تفضيلات الضيوف", href: "/guests", icon: Users },
    { name: "الإعدادات", href: "/settings", icon: Settings },
  ];

  const NavContent = () => (
    <div className="flex flex-col h-full bg-sidebar/50 backdrop-blur-xl border-l border-sidebar-border">
      <div className="p-6 flex items-center justify-center border-b border-sidebar-border/50">
        <div className="flex flex-col items-center gap-3">
          <div className="w-24 h-24 rounded-full bg-black flex items-center justify-center shadow-lg shadow-primary/20 overflow-hidden border-2 border-primary/20">
            <img src="/logo.png" alt="Digital Twin Hotel" className="w-full h-full object-cover" />
          </div>
          <div className="text-center">
            <h1 className="font-bold text-lg tracking-tight text-sidebar-foreground">Digital Twin</h1>
            <p className="text-xs text-sidebar-foreground/60 font-medium">Hotel System</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
        {navigation.map((item) => {
          const isActive = location === item.href;
          return (
            <Link key={item.name} href={item.href}>
              <div
                className={cn(
                  "flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 group cursor-pointer relative overflow-hidden",
                  isActive
                    ? "bg-sidebar-accent text-sidebar-accent-foreground shadow-md shadow-primary/10"
                    : "text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
                )}
              >
                {isActive && (
                  <div className="absolute right-0 top-0 bottom-0 w-1 bg-primary rounded-l-full" />
                )}
                <item.icon
                  className={cn(
                    "w-5 h-5 transition-transform duration-300 group-hover:scale-110",
                    isActive ? "text-primary" : "text-sidebar-foreground/50"
                  )}
                />
                <span className="font-medium">{item.name}</span>
              </div>
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-sidebar-border/50">
        <div className="bg-card/30 rounded-xl p-4 backdrop-blur-sm border border-white/5">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            <span className="text-xs font-medium text-muted-foreground">النظام متصل</span>
          </div>
          <div className="space-y-2">
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>استهلاك الطاقة</span>
              <span className="text-primary font-bold">84%</span>
            </div>
            <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
              <div className="h-full bg-gradient-to-r from-primary to-chart-3 w-[84%]" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background text-foreground font-sans selection:bg-primary/30" dir="rtl">
      <aside className="hidden lg:block fixed inset-y-0 right-0 w-72 z-50 border-l border-border bg-sidebar">
        <NavContent />
        <div className="absolute bottom-4 left-4 right-4">
           <Button
            variant="outline"
            size="sm"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            className="w-full flex items-center gap-2 justify-center"
          >
            {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            <span>{theme === "dark" ? "الوضع النهاري" : "الوضع الليلي"}</span>
          </Button>
        </div>
      </aside>

      <header className="lg:hidden fixed top-0 left-0 right-0 h-16 border-b border-border/50 bg-background/80 backdrop-blur-md z-50 flex items-center justify-between px-4">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-full bg-black flex items-center justify-center overflow-hidden border border-primary/20">
            <img src="/logo.png" alt="Logo" className="w-full h-full object-cover" />
          </div>
          <span className="font-bold text-lg">Digital Twin</span>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            className="text-foreground"
          >
            {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </Button>
        
          <Sheet open={isMobileOpen} onOpenChange={setIsMobileOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="hover:bg-primary/10">
              <Menu className="w-6 h-6" />
            </Button>
          </SheetTrigger>
          <SheetContent side="right" className="p-0 w-80 border-l border-border/50 bg-background/95 backdrop-blur-xl">
            <VisuallyHidden>
              <SheetTitle>قائمة التنقل</SheetTitle>
            </VisuallyHidden>
            <NavContent />
          </SheetContent>
        </Sheet>
        </div>
      </header>

      <main className="lg:mr-72 min-h-screen pt-16 lg:pt-0 transition-all duration-300">
        <div className="container py-6 lg:py-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
          {children}
        </div>
      </main>
      
      <div className="fixed inset-0 -z-10 pointer-events-none overflow-hidden">
        <div className="absolute top-[-20%] right-[-10%] w-[50%] h-[50%] rounded-full bg-primary/5 blur-[120px]" />
        <div className="absolute bottom-[-20%] left-[-10%] w-[50%] h-[50%] rounded-full bg-chart-3/5 blur-[120px]" />
      </div>
    </div>
  );
}
