import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { FileDown, Loader2 } from "lucide-react";
import { useSimulation } from "@/contexts/SimulationContext";
import { useToast } from "@/hooks/use-toast";

export default function ReportExport() {
  const [isExporting, setIsExporting] = useState(false);
  const { rooms, stats, aiLogs, isScenarioMode, csvData, selectedScenarioIndex } = useSimulation();
  const { toast } = useToast();

  const handleExport = async () => {
    setIsExporting(true);
    toast({ title: "جاري إنشاء التقرير...", description: "يرجى الانتظار بينما يتم تجهيز ملف HTML" });

    try {
      // Generate Detailed Room Table Rows
      const roomRows = Object.values(rooms).map(r => {
        const baselineConsumption = r.status === 'occupied' ? 10 : 5;
        const actualConsumption = r.floor === 1 ? baselineConsumption : (r.status === 'occupied' ? 7 : 1);
        const savingsKw = baselineConsumption - actualConsumption;
        const savingsUSD = savingsKw * 0.12;
        const savingsPercent = baselineConsumption > 0 ? ((savingsKw / baselineConsumption) * 100).toFixed(1) : '0.0';
        
        return `
          <tr class="border-b border-slate-800 hover:bg-slate-900/50">
            <td class="p-3 text-center">${r.id}</td>
            <td class="p-3 text-center">${r.floor}</td>
            <td class="p-3 text-center">
              <span class="px-2 py-1 rounded text-xs ${r.status === 'occupied' ? 'bg-blue-900 text-blue-300' : 'bg-slate-800 text-slate-400'}">
                ${r.status === 'occupied' ? 'مشغولة' : (r.status === 'cleaning' ? 'تنظيف' : 'فارغة')}
              </span>
            </td>
            <td class="p-3 text-right">${r.guestType ? r.guestType.split('(')[0] : '-'}</td>
            <td class="p-3 text-center">${r.temperature}°C</td>
            <td class="p-3 text-center">${r.light_level}%</td>
            <td class="p-3 text-center text-red-400">${baselineConsumption} kW</td>
            <td class="p-3 text-center text-green-400">${actualConsumption} kW</td>
            <td class="p-3 text-center text-blue-400 font-bold">${savingsKw} kW</td>
            <td class="p-3 text-center text-green-500 font-bold">$${savingsUSD.toFixed(2)}</td>
            <td class="p-3 text-center text-yellow-400 font-bold">${savingsPercent}%</td>
          </tr>
        `;
      }).join('');

      // Generate AI Logs Table Rows
      const aiRows = aiLogs.slice(0, 20).map(log => `
        <tr class="border-b border-slate-800">
          <td class="p-3 text-center text-slate-400">${log.timestamp}</td>
          <td class="p-3 text-center font-mono text-blue-300">${log.roomId || '-'}</td>
          <td class="p-3 text-right">${log.event}</td>
          <td class="p-3 text-right text-green-400">${log.action}</td>
          <td class="p-3 text-right text-slate-400 text-xs">${log.details || '-'}</td>
        </tr>
      `).join('');

      // Scenario Info
      let scenarioInfo = '';
      if (isScenarioMode && selectedScenarioIndex !== null && csvData[selectedScenarioIndex]) {
         const s = csvData[selectedScenarioIndex];
         scenarioInfo = `
           <div class="bg-yellow-900/20 border border-yellow-600/50 rounded-lg p-4 mb-8 text-center">
              <h3 class="text-yellow-400 font-bold text-lg mb-2">⚠️ تقرير وضع المحاكاة (Simulation Mode)</h3>
              <p class="text-slate-300">
                 تم توليد هذا التقرير بناءً على سيناريو محاكاة من البيانات التاريخية:
                 <span class="text-white font-mono mx-2">${new Date(s.timestamp).toLocaleDateString()} ${new Date(s.timestamp).toLocaleTimeString()}</span>
                 | نسبة الإشغال: <span class="text-white font-mono mx-2">${Math.round(s.occupancy * 100)}%</span>
                 | الحرارة الخارجية: <span class="text-white font-mono mx-2">${s.externalTemp}°C</span>
              </p>
           </div>
         `;
      }

      // Create a full HTML document with styles
      const htmlContent = `
        <!DOCTYPE html>
        <html dir="rtl" lang="ar">
        <head>
          <meta charset="UTF-8">
          <title>تقرير التوأم الرقمي - ${new Date().toLocaleString()}</title>
          <script src="https://cdn.tailwindcss.com"></script>
          <style>
            body { background-color: #020617; color: white; font-family: sans-serif; padding: 40px; }
            .card { background-color: #0f172a; border: 1px solid #1e293b; border-radius: 0.75rem; padding: 1.5rem; margin-bottom: 2rem; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1); }
            h1 { color: #60a5fa; font-size: 1.8rem; margin-bottom: 0.5rem; font-weight: bold; }
            h2 { color: #e2e8f0; font-size: 1.25rem; margin-bottom: 1rem; border-right: 4px solid #3b82f6; padding-right: 1rem; }
            table { width: 100%; border-collapse: collapse; font-size: 0.9rem; }
            th { text-align: right; padding: 0.75rem; color: #94a3b8; font-weight: 600; border-bottom: 1px solid #334155; background-color: #1e293b; }
            td { padding: 0.75rem; border-bottom: 1px solid #1e293b; }
            .stat-box { background: #1e293b; padding: 1rem; border-radius: 0.5rem; text-align: center; }
            .stat-value { font-size: 1.5rem; font-weight: bold; color: #fff; }
            .stat-label { font-size: 0.875rem; color: #94a3b8; margin-top: 0.25rem; }
          </style>
        </head>
        <body>
          <div class="container mx-auto max-w-6xl">
            
            <!-- HEADER -->
            <header class="mb-10 text-center border-b border-slate-800 pb-8">
              <h1 class="text-4xl text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-300">
                تقرير بحثي شامل: نظام التوأم الرقمي للفندق الذكي
              </h1>
              <p class="text-slate-400 mt-2">تاريخ التقرير: ${new Date().toLocaleString()}</p>
              
              <div class="mt-6 flex justify-center gap-6 text-sm bg-slate-900/50 inline-flex px-6 py-3 rounded-full border border-slate-800">
                <span class="text-green-400 font-bold">العملة المعتمدة: دولار أمريكي (USD)</span>
                <span class="text-slate-600">|</span>
                <span class="text-blue-400">تعرفة الكهرباء: $0.12/kWh</span>
              </div>
            </header>

            ${scenarioInfo}

            <!-- EXECUTIVE SUMMARY -->
            <div class="grid grid-cols-1 md:grid-cols-5 gap-4 mb-8">
              <div class="stat-box">
                <div class="stat-value text-blue-400">${stats.totalEnergy} kW</div>
                <div class="stat-label">إجمالي الاستهلاك</div>
              </div>
              <div class="stat-box">
                <div class="stat-value text-green-400">${stats.totalSavings} kW</div>
                <div class="stat-label">إجمالي التوفير (طاقة)</div>
              </div>
              <div class="stat-box">
                <div class="stat-value text-green-500">$${stats.totalCostSavings.toFixed(2)}</div>
                <div class="stat-label">إجمالي التوفير (مادي)</div>
              </div>
              <div class="stat-box">
                <div class="stat-value text-yellow-400">${stats.totalEnergy > 0 ? ((stats.totalSavings / (stats.totalEnergy + stats.totalSavings)) * 100).toFixed(1) : 0}%</div>
                <div class="stat-label">نسبة التوفير الكلية</div>
              </div>
              <div class="stat-box">
                <div class="stat-value text-purple-400">${aiLogs.length}</div>
                <div class="stat-label">قرارات الذكاء الاصطناعي</div>
              </div>
            </div>
            
            <!-- DETAILED ROOM DATA TABLE -->
            <div class="card">
              <h2>جدول بيانات الغرف التفصيلي (تحليل الأداء والتوفير)</h2>
              <div class="overflow-x-auto">
                <table>
                  <thead>
                    <tr>
                      <th class="text-center">الغرفة</th>
                      <th class="text-center">الطابق</th>
                      <th class="text-center">الحالة</th>
                      <th class="text-right">نوع النزيل (التخصيص)</th>
                      <th class="text-center">الحرارة</th>
                      <th class="text-center">الإضاءة</th>
                      <th class="text-center">الاستهلاك التقليدي</th>
                      <th class="text-center">الاستهلاك الفعلي</th>
                      <th class="text-center">التوفير (طاقة)</th>
                      <th class="text-center">التوفير (مادي)</th>
                      <th class="text-center">نسبة التوفير</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${roomRows}
                  </tbody>
                </table>
              </div>
            </div>

            <!-- AI DECISIONS LOG -->
            <div class="card">
              <h2>سجل قرارات الذكاء الاصطناعي (آخر 20 قرار)</h2>
              <div class="overflow-x-auto">
                <table>
                  <thead>
                    <tr>
                      <th class="text-center">الوقت</th>
                      <th class="text-center">الغرفة</th>
                      <th class="text-right">الحدث / السبب</th>
                      <th class="text-right">الإجراء المتخذ</th>
                      <th class="text-right">التفاصيل والمصدر</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${aiRows}
                  </tbody>
                </table>
              </div>
            </div>
            
            <footer class="mt-12 text-center text-slate-600 text-sm border-t border-slate-800 pt-6">
              <p>تم إنشاء هذا التقرير تلقائيًا بواسطة نظام التوأم الرقمي للفندق الذكي</p>
              <p class="mt-1">جميع الحقوق محفوظة © 2026</p>
            </footer>
          </div>
        </body>
        </html>
      `;

      const blob = new Blob([htmlContent], { type: 'text/html' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `Digital-Twin-Report-${Date.now()}.html`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      toast({ title: "تم تصدير التقرير بنجاح", description: "تم تحميل ملف HTML" });
    } catch (error) {
      console.error("Export failed:", error);
      toast({ variant: "destructive", title: "فشل التصدير", description: "حدث خطأ أثناء إنشاء التقرير" });
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <Button 
      onClick={handleExport} 
      disabled={isExporting}
      className="bg-blue-600 hover:bg-blue-700 text-white"
    >
      {isExporting ? (
        <>
          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          جاري التصدير...
        </>
      ) : (
        <>
          <FileDown className="mr-2 h-4 w-4" />
          تصدير تقرير بحثي (HTML)
        </>
      )}
    </Button>
  );
}
