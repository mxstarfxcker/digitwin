import React, { useRef, useState } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Text, Environment, ContactShadows } from '@react-three/drei';
import * as THREE from 'three';

// --- OLD MODEL IMPLEMENTATION ---

const Room = ({ position, color, roomId, onClick, isEmergency }: any) => {
  const [hovered, setHovered] = useState(false);
  const mesh = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (isEmergency && mesh.current) {
      const t = state.clock.getElapsedTime();
      (mesh.current.material as THREE.MeshStandardMaterial).emissiveIntensity = (Math.sin(t * 10) + 1) / 2;
    }
  });

  return (
    <group position={position}>
      <mesh
        ref={mesh}
        onClick={(e) => { e.stopPropagation(); onClick(roomId); }}
        onPointerOver={() => setHovered(true)}
        onPointerOut={() => setHovered(false)}
      >
        <boxGeometry args={[1.8, 1, 1.8]} />
        <meshStandardMaterial 
          color={color} 
          transparent 
          opacity={0.9}
          emissive={color}
          emissiveIntensity={isEmergency ? 1 : 0.2}
        />
      </mesh>
      <mesh position={[0, 0, 0.91]}>
        <planeGeometry args={[1.5, 0.8]} />
        <meshStandardMaterial color="#000" />
      </mesh>
      <Text
        position={[0, 0, 0.92]}
        fontSize={0.4}
        color="white"
        anchorX="center"
        anchorY="middle"
      >
        {roomId}
      </Text>
    </group>
  );
};

const Floor = ({ level, rooms, onRoomClick, isEmergency, isIsolated }: any) => {
  return (
    <group position={[0, (level - 1) * 1.5, 0]}>
      <mesh position={[0, -0.6, 0]}>
        <boxGeometry args={[12, 0.2, 4]} />
        <meshStandardMaterial color={isIsolated ? "#333" : "#666"} />
      </mesh>
      {rooms.map((room: any, idx: number) => (
        <Room
          key={room.id}
          position={[(idx - 2.5) * 2, 0, 0]}
          color={
            isEmergency ? '#ff0000' :
            isIsolated ? '#333' :
            room.status === 'occupied' ? '#ef4444' :
            room.status === 'cleaning' ? '#eab308' :
            '#22c55e'
          }
          roomId={room.id}
          onClick={onRoomClick}
          isEmergency={isEmergency}
        />
      ))}
    </group>
  );
};

export default function HotelModel({ roomData, isEmergency, floorIsolation, onRoomClick }: { roomData: any, isEmergency: boolean, floorIsolation: any, onRoomClick?: (id: string) => void }) {
  // Group rooms by floor
  const floors = [1, 2, 3, 4, 5].map(level => ({
    level,
    rooms: roomData.filter((r: any) => r.floor === level)
  }));

  return (
    <div className="w-full h-[500px] bg-slate-900 rounded-xl overflow-hidden relative">
      <div className="absolute top-4 left-4 z-10 bg-black/50 p-2 rounded text-white text-xs">
        Legacy Model (v1.0)
      </div>
      <Canvas camera={{ position: [10, 8, 10], fov: 50 }}>
        <ambientLight intensity={0.5} />
        <pointLight position={[10, 10, 10]} />
        <Environment preset="city" />
        <group position={[0, -2, 0]}>
          {floors.map(floor => (
            <Floor
              key={floor.level}
              level={floor.level}
              rooms={floor.rooms}
              onRoomClick={onRoomClick}
              isEmergency={isEmergency}
              isIsolated={floorIsolation[floor.level]}
            />
          ))}
        </group>
        <OrbitControls />
      </Canvas>
    </div>
  );
}
