import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Activity, Thermometer, Zap, Eye, CheckCircle2, AlertCircle, Timer } from "lucide-react";
import { useSimulation } from "@/contexts/SimulationContext";

export default function SensorNetwork() {
  const { rooms } = useSimulation();

  // Calculate sensor performance metrics
  const sensorMetrics = Object.values(rooms).map(room => {
    const isOccupied = room.status === 'occupied';
    const isControlGroup = room.floor === 1;

    // Mock sensor efficiency logic
    // Control Group (Floor 1): High response time (inefficient), 0% savings
    // Experimental Groups (Floor 2 & 3): Low response time (efficient), high savings
    const responseTime = isControlGroup 
      ? Math.floor(Math.random() * 800) + 1200 // 1200-2000ms (Slow)
      : (isOccupied ? Math.floor(Math.random() * 200) + 50 : Math.floor(Math.random() * 500) + 200); // Fast
      
    const accuracy = isControlGroup ? 85.0 : (isOccupied ? 99.8 : 98.5); // %
    
    const energySaved = isControlGroup 
      ? 0 // No savings in traditional system
      : (isOccupied ? 0 : Math.floor(Math.random() * 15) + 5); // % saved when vacant

    return {
      id: room.id,
      floor: room.floor,
      status: isControlGroup ? 'traditional' : (isOccupied ? 'active' : 'standby'),
      responseTime,
      accuracy,
      energySaved,
      lastReading: isOccupied ? 'Motion Detected' : 'No Motion',
      tempReading: room.temperature,
      isControlGroup
    };
  });

  return (
    <Card className="bg-slate-950 border-slate-800 mt-6">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-cyan-400">
          <Activity className="w-5 h-5" /> شبكة الحساسات الذكية (IoT Sensor Network)
        </CardTitle>
        <CardDescription>تقرير تفصيلي عن أداء الحساسات واستجابة النظام لكل غرفة</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="bg-slate-900/50 p-4 rounded-xl border border-slate-800 flex items-center gap-4">
            <div className="p-3 bg-green-500/10 rounded-full">
              <CheckCircle2 className="w-6 h-6 text-green-500" />
            </div>
            <div>
              <div className="text-2xl font-bold text-white">99.2%</div>
              <div className="text-xs text-slate-400">دقة القراءات</div>
            </div>
          </div>
          <div className="bg-slate-900/50 p-4 rounded-xl border border-slate-800 flex items-center gap-4">
            <div className="p-3 bg-blue-500/10 rounded-full">
              <Timer className="w-6 h-6 text-blue-500" />
            </div>
            <div>
              <div className="text-2xl font-bold text-white">120ms</div>
              <div className="text-xs text-slate-400">متوسط زمن الاستجابة</div>
            </div>
          </div>
          <div className="bg-slate-900/50 p-4 rounded-xl border border-slate-800 flex items-center gap-4">
            <div className="p-3 bg-yellow-500/10 rounded-full">
              <AlertCircle className="w-6 h-6 text-yellow-500" />
            </div>
            <div>
              <div className="text-2xl font-bold text-white">0</div>
              <div className="text-xs text-slate-400">أعطال الحساسات</div>
            </div>
          </div>
        </div>

        <ScrollArea className="h-[400px] pr-4">
          <div className="space-y-3">
            {sensorMetrics.map((sensor) => (
              <div key={sensor.id} className="flex items-center justify-between p-3 bg-slate-900/30 border border-slate-800 rounded-lg hover:bg-slate-900/60 transition-colors">
                
                {/* Room & Status */}
                <div className="flex items-center gap-4 min-w-[150px]">
                  <div className={`w-2 h-2 rounded-full ${sensor.status === 'active' ? 'bg-green-500 animate-pulse' : 'bg-slate-500'}`} />
                  <div>
                    <div className="font-medium text-slate-200">غرفة {sensor.id}</div>
                    <div className="text-xs text-slate-500">طابق {sensor.floor}</div>
                  </div>
                </div>

                {/* Readings */}
                <div className="flex gap-6 text-sm">
                  <div className="flex items-center gap-2 text-slate-400" title="الحرارة">
                    <Thermometer className="w-4 h-4 text-red-400" />
                    <span>{sensor.tempReading}°C</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-400" title="الحركة">
                    <Eye className="w-4 h-4 text-blue-400" />
                    <span>{sensor.lastReading}</span>
                  </div>
                </div>

                {/* Performance Stats */}
                <div className="flex gap-4 items-center">
                  <div className="text-right">
                    <div className="text-xs text-slate-500">الاستجابة</div>
                    <div className={`text-sm font-mono ${sensor.isControlGroup ? 'text-red-400' : 'text-cyan-400'}`}>
                      {sensor.responseTime}ms
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs text-slate-500">توفير الطاقة</div>
                    <div className={`text-sm font-mono ${sensor.energySaved > 0 ? 'text-green-400' : 'text-slate-500'}`}>
                      {sensor.energySaved > 0 ? `-${sensor.energySaved}%` : '0%'}
                    </div>
                  </div>
                </div>

                {/* Action Badge */}
                <Badge variant="outline" className={`
                  ${sensor.status === 'active' ? 'border-green-500/30 text-green-400' : ''}
                  ${sensor.status === 'standby' ? 'border-slate-700 text-slate-500' : ''}
                  ${sensor.status === 'traditional' ? 'border-red-500/30 text-red-400' : ''}
                `}>
                  {sensor.status === 'active' && 'مراقبة نشطة'}
                  {sensor.status === 'standby' && 'وضع السكون'}
                  {sensor.status === 'traditional' && 'نظام تقليدي'}
                </Badge>

              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
